UPDATE x_read_me SET x_active = TRUE WHERE x_active IS NULL;
