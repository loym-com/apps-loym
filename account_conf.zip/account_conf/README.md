# hr_expense_no

Minimal Odoo 19 module for testing translation precedence.

## Purpose

The module depends on `hr_expense` and provides a Norwegian translation:

    Customer -> Klient

This is intentionally a small test module.

## Suggested test

1. Install `hr_expense`.
2. Install `hr_expense_no`.
3. Verify the Norwegian translation of `Customer`.
4. Change the `account` module translation from `Kunde` to `Kund`.
5. Update Norwegian without "Overwrite Existing Terms".
6. Check the result.
7. Repeat with "Overwrite Existing Terms" enabled.

The PO entry is deliberately associated with this module so that the test can
show how Odoo handles a translation supplied by a dependent custom module.
