from odoo import Command
from odoo.exceptions import AccessError, UserError
from odoo.tests import TransactionCase, tagged


@tagged("post_install", "-at_install")
class TestOfferingSecurity(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.journal = cls.env.ref("account_offering.journal_offering")
        tag = cls.env.ref("account_offering.account_tag_default_offering")
        offering_tag = cls.env.ref("account_offering.account_tag_offering")
        cls.accounts = cls.env["account.account"].create([
            {
                "name": "Offering asset",
                "code": "100001",
                "account_type": "asset_current",
                "tag_ids": [Command.set([tag.id, offering_tag.id])],
            },
            {
                "name": "Offering income",
                "code": "400001",
                "account_type": "income",
                "tag_ids": [Command.set([tag.id, offering_tag.id])],
            },
        ])
        cls.other_journal = cls.env["account.journal"].create({
            "name": "Other journal",
            "code": "OTHER",
            "type": "general",
        })
        cls.user = cls.env["res.users"].with_context(no_reset_password=True).create({
            "name": "Offering user",
            "login": "offering-security-test",
            "group_ids": [Command.set([cls.env.ref("account_offering.group_offering_user").id])],
        })
        cls.other_move = cls.env["account.move"].create({
            "journal_id": cls.other_journal.id,
            "line_ids": [
                Command.create({"account_id": cls.accounts[0].id, "debit": 1}),
                Command.create({"account_id": cls.accounts[1].id, "credit": 1}),
            ],
        })

    def test_registration_posting_and_journal_isolation(self):
        self.assertFalse(self.user.has_group("account.group_account_invoice"))
        user_env = self.env(user=self.user)
        self.assertFalse(user_env["account.journal"].search([("id", "=", self.other_journal.id)]))
        self.assertFalse(user_env["account.move"].search([("id", "=", self.other_move.id)]))
        self.assertFalse(user_env["account.move.line"].search([("move_id", "=", self.other_move.id)]))
        with self.assertRaises(AccessError), self.cr.savepoint():
            self.other_move.with_user(self.user).read(["ref"])
        with self.assertRaises(AccessError), self.cr.savepoint():
            self.other_move.with_user(self.user).write({"ref": "Forbidden"})
        with self.assertRaises(AccessError), self.cr.savepoint():
            user_env["account.move"].create({"journal_id": self.other_journal.id})

        post = self.env.ref("account_offering.action_offering_post")
        with self.assertRaises(AccessError), self.cr.savepoint():
            post.with_user(self.user).with_context(
                active_model="account.move",
                active_id=self.other_move.id,
                active_ids=self.other_move.ids,
            ).run()
        with self.assertRaises(UserError), self.cr.savepoint():
            post.with_context(
                active_model="account.move",
                active_id=self.other_move.id,
                active_ids=self.other_move.ids,
            ).run()

        self.env.ref("account_offering.action_account_offering").with_user(self.user).run()
        move = user_env["account.move"].search([("journal_id", "=", self.journal.id)], limit=1)
        self.assertTrue(move)
        self.assertEqual(len(move.line_ids), 2)
        move.write({"ref": "Updated offering"})
        with self.assertRaises((AccessError, UserError)), self.cr.savepoint():
            move.write({"journal_id": self.other_journal.id})
        with self.assertRaises((AccessError, UserError)), self.cr.savepoint():
            move.line_ids[0].write({"move_id": self.other_move.id})
        empty_move = user_env["account.move"].create({"journal_id": self.journal.id})
        with self.assertRaises((AccessError, UserError)), self.cr.savepoint():
            empty_move.write({"journal_id": self.other_journal.id})
        ordinary_user = self.env["res.users"].with_context(no_reset_password=True).create({
            "name": "Ordinary internal user",
            "login": "offering-ordinary-test",
            "group_ids": [Command.set([self.env.ref("base.group_user").id])],
        })
        with self.assertRaises(AccessError), self.cr.savepoint():
            post.with_user(ordinary_user).with_context(
                active_model="account.move", active_id=move.id, active_ids=move.ids,
            ).run()

        user_env["account.move"].get_views([
            (self.env.ref("account_offering.view_account_move_form_offering").id, "form"),
        ])
        post.with_user(self.user).with_context(
            active_model="account.move", active_id=move.id, active_ids=move.ids,
        ).run()
        self.assertEqual(move.state, "posted")
