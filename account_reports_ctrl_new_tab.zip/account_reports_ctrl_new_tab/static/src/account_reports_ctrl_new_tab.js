/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { AccountReportLineCell } from "@account_reports/components/account_report/line_cell/line_cell";

let modifiedReportClick = false;

document.addEventListener(
    "click",
    ev => modifiedReportClick = ev.ctrlKey || ev.metaKey,
    true
);

patch(AccountReportLineCell.prototype, {
    async audit() {
        const newWindow = modifiedReportClick;
        modifiedReportClick = false;

        if (!newWindow) {
            return super.audit();
        }

        const doAction = this.action.doAction;

        this.action.doAction = (action, options = {}) =>
            doAction.call(this.action, action, { ...options, newWindow: true });

        try {
            return await super.audit();
        } finally {
            this.action.doAction = doAction;
        }
    },
});









// /** @odoo-module **/

// import { markup } from "@odoo/owl";
// import { patch } from "@web/core/utils/patch";
// import { AccountReportLineCell } from "@account_reports/components/account_report/line_cell/line_cell";

// let modifiedReportClick = false;

// document.addEventListener("click", ev => modifiedReportClick = ev.ctrlKey || ev.metaKey, true);

// patch(AccountReportLineCell.prototype, {
//     async audit() {
//         const newWindow = modifiedReportClick;
//         modifiedReportClick = false;

//         const auditAction = await this.orm.call(
//             "account.report",
//             "dispatch_report_action",
//             [
//                 this.controller.options.report_id,
//                 this.controller.options,
//                 "action_audit_cell",
//                 {
//                     report_line_id: this.props.cell.report_line_id || null,
//                     expression_label: this.props.cell.expression_label,
//                     calling_line_dict_id: this.props.line.id,
//                     column_group_index: this.props.cell.column_group_index,
//                 },
//             ],
//             {
//                 context: this.controller.context,
//             }
//         );

//         if (auditAction.help) {
//             auditAction.help = markup(auditAction.help);
//         }

//         return this.action.doAction(auditAction, {
//             newWindow,
//         });
//     },
// });
